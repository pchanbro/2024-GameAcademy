#include "pch.h"
#include "Flipbook.h"
Flipbook::Flipbook()
{

}
Flipbook::~Flipbook()
{

}