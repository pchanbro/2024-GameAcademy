#pragma once
class ResourceBase
{
public:
	ResourceBase();
	virtual ~ResourceBase();
};