#include "pch.h"
#include "ResourceBase.h"

ResourceBase::ResourceBase() 
{
}
ResourceBase::~ResourceBase() 
{
}