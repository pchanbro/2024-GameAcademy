#include "pch.h"
#include "Component.h"
void Component::Init()
{

}
void Component::Render(HDC hdc)
{

}
void Component::Update()
{

}
void Component::Release()
{

}